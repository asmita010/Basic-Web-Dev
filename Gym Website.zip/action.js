if (document.readyState == 'loading') {
    document.addEventListener('DOMContentLoaded',ready)
} 
else {
    ready()
}

var i;
i=0;
showimg(0)
function ready()
{
console.log("Ready")
}
function dot(j)
{
    i=j
    showimg(i)
}
function showimg(i)
{
    
    var p = document.getElementsByClassName('fact-1')
    for (let j = 0 ; j < p.length ; j++)
    {
        p[j].style.display = "none"
    }
    p[i].style.display = "flex";
    p[i].style.justifyContent = "center";
    p[i].style.alignItems = "center";
    
}

function automat()
{
    var p = document.getElementsByClassName('fact-1');
    
        
        for (let j = 0 ; j < p.length ; j++)
        {
            p[j].style.display = "none";
        }
    p[i].style.display = "flex";
    p[i].style.alignItems = "center";
    p[i].style.justifycontent = "center";
    i++;
    if (i==p.length) 
    {
        i=0;
    }
    
}
function automatcall() 
{
    var myvar;
    myvar = setInterval(automat , 5000);
}



