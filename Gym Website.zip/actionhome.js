if (document.readyState == 'loading') {
    document.addEventListener('DOMContentLoaded',ready)
} 
else {
    ready()
}

var ai;
ai=0;
showimg(0)
function ready()
{
console.log("Ready")
}


function showimg(ai)
{
    
    var p = document.getElementsByClassName('test-cont')
    for (let j = 0 ; j < p.length ; j++)
    {
        p[j].style.display = "none"
    }
    p[ai].style.display = "block"
}
function aboutautomat()
{
    
    var p = document.getElementsByClassName('test-cont');
    
        
        for (let j = 0 ; j < p.length ; j++)
        {
            p[j].style.display = "none";
        }
    p[ai].style.display = "block";
    ai++;
    if (ai==p.length) 
    {
        ai=0;
    }
    
}
function aboutautomatcall() 
{
    var myvar;
    myvar = setInterval(aboutautomat , 2000);
}