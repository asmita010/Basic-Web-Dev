
<?php
header("location:home.html");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name = $_POST["name"];
  $email = $_POST["mail"];
  $password = $_POST["password"];
  $cont = $_POST["contact"];

  echo "<script>alert('Account Created $name');</script>";
}


?>