console.log("HEY");
function sub()
{
    var name=document.getElementById('name').value;
    var password=document.getElementById('password').value;
    var cont=document.getElementById('contact').value;
    var mail=document.getElementById('mail').value;
    alert("Account Created "+name)
    
}